/* ───────────────────────────────────────────────────────────────────────────
   main.js  –  Intelligent Study Planner Frontend Logic
─────────────────────────────────────────────────────────────────────────── */

// ── Tab switching ────────────────────────────────────────────────────────────

function showTab(name) {
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));

  document.getElementById(`tab${cap(name)}`).classList.add("active");
  document.getElementById(`tab${cap(name)}Btn`).classList.add("active");

  if (name === "history") loadHistory();
}

function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ── Form submit ──────────────────────────────────────────────────────────────

async function submitForm(e) {
  e.preventDefault();

  const btn    = document.getElementById("submitBtn");
  const btnTxt = document.getElementById("btnText");
  const loader = document.getElementById("btnLoader");

  // Loading state
  btn.disabled = true;
  btnTxt.textContent = "Generating…";
  loader.classList.remove("hidden");

  const payload = {
    username:    document.getElementById("username").value.trim(),
    subject:     document.getElementById("subject").value.trim(),
    difficulty:  parseFloat(document.getElementById("difficulty").value),
    time_left:   parseInt(document.getElementById("time_left").value),
    preparation: parseFloat(document.getElementById("preparation").value),
    exam_marks:  parseInt(document.getElementById("exam_marks").value),
  };

  try {
    const res  = await fetch("/generate-plan", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      showToast("❌ " + (data.error || "Something went wrong."), "error");
      return;
    }

    displayResult(data);
    showToast("✅ Plan generated successfully!");

  } catch (err) {
    showToast("❌ Network error: " + err.message, "error");
  } finally {
    btn.disabled = false;
    btnTxt.textContent = "⚡ Generate Study Plan";
    loader.classList.add("hidden");
  }
}

// ── Render result panel ──────────────────────────────────────────────────────

function displayResult(data) {
  // Hide placeholder, show result
  document.getElementById("placeholder").classList.add("hidden");
  const rc = document.getElementById("resultContent");
  rc.classList.remove("hidden");

  // Score strip
  document.getElementById("resPriority").textContent = data.priority_score.toFixed(1);
  document.getElementById("resHours").textContent    = data.study_hours.toFixed(1) + " hrs";
  document.getElementById("resSubject").textContent  = data.subject;

  // Priority bar
  const barFill = document.getElementById("priorityBarFill");
  const barLabel = document.getElementById("priorityLabel");
  const pct = Math.min(100, Math.max(0, data.priority_score));

  barFill.style.width = "0%";
  setTimeout(() => { barFill.style.width = pct + "%"; }, 50);

  let lvl = "Low";
  if (pct >= 65) lvl = "High";
  else if (pct >= 35) lvl = "Medium";
  barLabel.textContent = `Priority: ${lvl} (${pct.toFixed(1)} / 100)`;

  // Plan text
  document.getElementById("resPlan").textContent  = data.plan;
  document.getElementById("resDate").textContent  = "Generated: " + data.date;

  // Smooth scroll to result on mobile
  if (window.innerWidth < 769) {
    document.getElementById("resultCard").scrollIntoView({ behavior: "smooth" });
  }
}

// ── History tab ──────────────────────────────────────────────────────────────

async function loadHistory() {
  const container = document.getElementById("historyList");
  container.innerHTML = `<div class="placeholder"><div class="placeholder-icon">⏳</div><p>Loading…</p></div>`;

  try {
    const res  = await fetch("/plans");
    const data = await res.json();

    if (!res.ok || data.error) {
      container.innerHTML = `<div class="placeholder"><p>❌ ${data.error || "Failed to load."}</p></div>`;
      return;
    }

    if (!data.plans.length) {
      container.innerHTML = `<div class="placeholder"><div class="placeholder-icon">📭</div><p>No plans saved yet. Generate one first!</p></div>`;
      return;
    }

    container.innerHTML = data.plans.map((p, i) => buildHistoryItem(p, i)).join("");

  } catch (err) {
    container.innerHTML = `<div class="placeholder"><p>❌ Network error: ${err.message}</p></div>`;
  }
}

function buildHistoryItem(p, idx) {
  const pct   = Math.min(100, Math.max(0, p.priority));
  let   tier  = "low";
  if (pct >= 65) tier = "high";
  else if (pct >= 35) tier = "medium";
  const tierLabel = tier.charAt(0).toUpperCase() + tier.slice(1);

  const planText = (p.plan || "No plan text.").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  return `
    <div class="history-item" onclick="toggleDetail('detail-${idx}')">
      <div style="display: flex; justify-content: space-between; align-items: flex-start;">
        <h3>
          📖 ${escHtml(p.subject)}
          <span class="hist-badge ${tier}">${tierLabel} Priority</span>
        </h3>
        <button onclick="deletePlan(${p.id}, event)" style="background: none; border: none; color: var(--red, #ef4444); cursor: pointer; font-size: 1.2rem; padding: 0.2rem;" title="Delete Plan">🗑️</button>
      </div>
      <div class="history-meta">
        <span>⚡ Priority: ${pct.toFixed(1)}</span>
        <span>⏱ ${p.hours.toFixed(1)} hrs/day</span>
        <span>📅 ${p.date}</span>
      </div>
      <div class="history-detail" id="detail-${idx}">${planText}</div>
    </div>`;
}

function toggleDetail(id) {
  const el = document.getElementById(id);
  el.style.display = el.style.display === "block" ? "none" : "block";
}

function escHtml(str) {
  return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// ── Toast notification ───────────────────────────────────────────────────────

let _toastTimer = null;

function showToast(msg, type = "success") {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.style.borderColor = type === "error" ? "var(--red)" : "var(--green)";
  toast.classList.remove("hidden");
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => toast.classList.add("hidden"), 3500);
}

// ── Delete plan ──────────────────────────────────────────────────────────────

async function deletePlan(id, event) {
  event.stopPropagation();
  if (!confirm("Are you sure you want to delete this study plan?")) return;
  
  try {
    const res = await fetch(`/plans/${id}`, { method: "DELETE" });
    const data = await res.json();
    
    if (!res.ok || data.error) {
      showToast("❌ " + (data.error || "Failed to delete."), "error");
      return;
    }
    
    showToast("✅ Plan deleted successfully!");
    loadHistory();
  } catch (err) {
    showToast("❌ Network error: " + err.message, "error");
  }
}
